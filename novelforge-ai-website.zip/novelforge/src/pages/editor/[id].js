// src/pages/editor/[id].js
import { useState, useEffect, useRef } from 'react'
import { useRouter } from 'next/router'
import Notification, { notify } from '../../components/Notification'
import { useAuth } from '../_app'
import { GENRES } from '../../lib/pricing'

export default function EditorPage() {
  const router = useRouter()
  const { user, apiFetch, theme, toggleTheme } = useAuth()
  const [project, setProject] = useState(null)
  const [loading, setLoading] = useState(true)
  const [selectedChapter, setSelectedChapter] = useState(null)
  const [editText, setEditText] = useState(null)
  const [generating, setGenerating] = useState(false)
  const [genStatus, setGenStatus] = useState('')
  const [genProgress, setGenProgress] = useState(0)
  const [genCurrentChapter, setGenCurrentChapter] = useState(0)
  const [saving, setSaving] = useState(false)
  const stopRef = useRef(false)

  useEffect(() => {
    if (!user) { router.push('/auth'); return }
    const { id } = router.query
    if (id) fetchProject(id)
  }, [user, router.query])

  const fetchProject = async (id) => {
    try {
      const res = await apiFetch(`/api/projects/${id}`)
      const data = await res.json()
      if (!res.ok) { router.push('/dashboard'); return }
      setProject(data.project)
    } catch {
      router.push('/dashboard')
    } finally {
      setLoading(false)
    }
  }

  const wordCount = (text) => text ? text.trim().split(/\s+/).filter(Boolean).length : 0

  const generateAll = async () => {
    if (generating) return
    stopRef.current = false
    setGenerating(true)
    setGenProgress(3)

    try {
      let currentProject = project

      // Generate outline if not exists
      if (!currentProject.outline) {
        setGenStatus('✦ Crafting your story outline…')
        setGenProgress(5)
        const res = await apiFetch(`/api/projects/${currentProject._id}/generate-outline`, { method:'POST' })
        const data = await res.json()
        if (!res.ok) throw new Error(data.error)
        currentProject = { ...currentProject, outline: data.outline, title: data.project.title }
        setProject(currentProject)
        setGenProgress(15)
      }

      // Generate chapters sequentially
      const startFrom = (currentProject.chapters?.length || 0) + 1
      let prevSummary = ''

      // Get summary from last chapter if resuming
      if (currentProject.chapters?.length > 0) {
        const lastChapter = currentProject.chapters[currentProject.chapters.length - 1]
        if (lastChapter.text) {
          const res = await apiFetch(`/api/projects/${currentProject._id}/generate-outline`, {})
        }
      }

      for (let i = startFrom; i <= currentProject.maxChapters; i++) {
        if (stopRef.current) break

        setGenCurrentChapter(i)
        setGenStatus(`✍️ Writing Chapter ${i} of ${currentProject.maxChapters}…`)
        setGenProgress(15 + Math.round(((i - startFrom) / (currentProject.maxChapters - startFrom + 1)) * 80))

        const res = await apiFetch(`/api/projects/${currentProject._id}/generate-chapter`, {
          method: 'POST',
          body: JSON.stringify({ chapterNumber: i, prevSummary }),
        })
        const data = await res.json()
        if (!res.ok) throw new Error(data.error)

        prevSummary = data.summary
        const newChapters = [...(currentProject.chapters || []).filter(c => c.number !== i), data.chapter]
          .sort((a, b) => a.number - b.number)
        currentProject = { ...currentProject, chapters: newChapters }
        setProject({ ...currentProject })

        // Auto-select first chapter
        if (i === startFrom) setSelectedChapter(data.chapter)
      }

      setGenProgress(100)
      setGenStatus(stopRef.current ? '⏸ Paused' : '🎉 Novel complete!')
      notify(stopRef.current ? 'Generation paused' : 'Novel generation complete!')
    } catch (err) {
      notify('Generation error: ' + err.message, 'error')
      setGenStatus('Error: ' + err.message)
    } finally {
      setGenerating(false)
    }
  }

  const saveEdit = async () => {
    if (!selectedChapter || editText === null) return
    setSaving(true)
    const wc = wordCount(editText)
    const updatedChapters = project.chapters.map(c =>
      c.number === selectedChapter.number ? { ...c, text: editText, wordCount: wc } : c
    )
    const totalWords = updatedChapters.reduce((s, c) => s + (c.wordCount || 0), 0)
    try {
      await apiFetch(`/api/projects/${project._id}`, {
        method: 'PATCH',
        body: JSON.stringify({ chapters: updatedChapters, totalWords }),
      })
      const newChap = { ...selectedChapter, text: editText, wordCount: wc }
      setProject({ ...project, chapters: updatedChapters, totalWords })
      setSelectedChapter(newChap)
      setEditText(null)
      notify('Chapter saved!')
    } catch {
      notify('Save failed', 'error')
    } finally {
      setSaving(false)
    }
  }

  const downloadTXT = () => {
    const lines = [
      project.title,
      `Genre: ${GENRES.find(g => g.id === project.genre)?.label}`,
      project.outline?.logline ? `\n${project.outline.logline}` : '',
      '',
      ...(project.chapters || []).flatMap(ch => [
        `\n${'─'.repeat(60)}`,
        `Chapter ${ch.number}: ${ch.title}`,
        `${'─'.repeat(60)}\n`,
        ch.text, '',
      ]),
    ]
    const blob = new Blob([lines.join('\n')], { type: 'text/plain' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = `${project.title.replace(/\s+/g, '-')}.txt`
    a.click()
    notify('Downloaded!')
  }

  if (!user || loading) return (
    <div style={{ minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'var(--bg)' }}>
      <div className="spinner" style={{ width:40, height:40 }} />
    </div>
  )

  if (!project) return null

  const genre = GENRES.find(g => g.id === project.genre)
  const chaptersDone = project.chapters?.length || 0
  const progress = project.maxChapters ? Math.round(chaptersDone / project.maxChapters * 100) : 0

  return (
    <div style={{ height:'100vh', display:'flex', flexDirection:'column', overflow:'hidden' }}>
      <Notification />

      {/* Top Bar */}
      <div style={{
        background:'var(--surface)', borderBottom:'1px solid var(--border)',
        padding:'0 20px', height:58, display:'flex', alignItems:'center',
        justifyContent:'space-between', flexShrink:0, zIndex:10,
      }}>
        <div style={{ display:'flex', alignItems:'center', gap:12 }}>
          <button className="btn-ghost" style={{ padding:'7px 14px', fontSize:13 }} onClick={() => router.push('/dashboard')}>← Dashboard</button>
          <div style={{ width:1, height:24, background:'var(--border)' }} />
          <span className="playfair" style={{ fontWeight:700, fontSize:16, color:'var(--accent)' }}>📖 NovelForge AI</span>
        </div>
        <div style={{ display:'flex', gap:10, alignItems:'center' }}>
          {project.chapters?.length > 0 && (
            <button className="btn-ghost" style={{ padding:'7px 16px', fontSize:13 }} onClick={downloadTXT}>⬇ Download TXT</button>
          )}
          <button className="btn-ghost" onClick={toggleTheme} style={{ padding:'7px 10px', fontSize:16 }}>
            {theme === 'dark' ? '☀️' : '🌙'}
          </button>
        </div>
      </div>

      <div style={{ flex:1, display:'flex', overflow:'hidden' }}>
        {/* Sidebar */}
        <div style={{ width:260, background:'var(--surface)', borderRight:'1px solid var(--border)', display:'flex', flexDirection:'column', overflow:'hidden', flexShrink:0 }}>

          {/* Project info */}
          <div style={{ padding:'16px', borderBottom:'1px solid var(--border)', flexShrink:0 }}>
            <div style={{ fontWeight:700, fontSize:14, marginBottom:3, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
              {project.title}
            </div>
            <div style={{ fontSize:12, color:'var(--muted)', marginBottom:10 }}>
              {genre?.emoji} {genre?.label}
            </div>
            <div className="progress-bar">
              <div className="progress-fill" style={{ width:`${progress}%` }} />
            </div>
            <div style={{ fontSize:11, color:'var(--muted)', marginTop:5, display:'flex', justifyContent:'space-between' }}>
              <span>{chaptersDone}/{project.maxChapters} chapters</span>
              <span>{progress}%</span>
            </div>
          </div>

          {/* Outline summary */}
          {project.outline && (
            <div style={{ padding:'12px 16px', borderBottom:'1px solid var(--border)', flexShrink:0 }}>
              <div
                style={{ fontWeight:600, fontSize:12, color:'var(--accent)', marginBottom:6, cursor:'pointer' }}
                onClick={() => { setSelectedChapter(null); setEditText(null) }}
              >
                📋 STORY OUTLINE
              </div>
              <div style={{ fontSize:11, color:'var(--muted)', lineHeight:1.5 }}>
                {project.outline.logline?.substring(0, 100)}…
              </div>
            </div>
          )}

          {/* Chapter list */}
          <div style={{ flex:1, overflowY:'auto', padding:'8px' }}>
            {(project.chapters || []).map(ch => (
              <div key={ch.number}
                onClick={() => { setSelectedChapter(ch); setEditText(null) }}
                style={{
                  padding:'9px 12px', borderRadius:8, cursor:'pointer', marginBottom:2,
                  background: selectedChapter?.number===ch.number ? 'color-mix(in srgb, var(--accent) 15%, transparent)' : 'transparent',
                  borderLeft: selectedChapter?.number===ch.number ? '3px solid var(--accent)' : '3px solid transparent',
                  transition:'all 0.12s',
                }}
              >
                <div style={{ fontWeight:500, fontSize:13, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                  Ch.{ch.number}: {ch.title}
                </div>
                <div style={{ fontSize:11, color:'var(--muted)', marginTop:2 }}>
                  {(ch.wordCount || wordCount(ch.text)).toLocaleString()} words
                </div>
              </div>
            ))}

            {/* Generating skeleton */}
            {generating && (
              <div style={{ padding:'9px 12px', animation:'pulse 1s infinite' }}>
                <div className="skeleton" style={{ width:'80%', height:13, marginBottom:6 }} />
                <div className="skeleton" style={{ width:'50%', height:10 }} />
              </div>
            )}
          </div>

          {/* Actions */}
          <div style={{ padding:'12px', borderTop:'1px solid var(--border)', display:'flex', flexDirection:'column', gap:8, flexShrink:0 }}>
            {chaptersDone < project.maxChapters && !generating && (
              <button className="btn-gold" style={{ fontSize:13, padding:'10px' }} onClick={generateAll}>
                {chaptersDone === 0 ? '✦ Generate Novel' : `✦ Continue (Ch. ${chaptersDone + 1})`}
              </button>
            )}
            {generating && (
              <button
                style={{ background:'color-mix(in srgb, var(--red) 15%, transparent)', color:'var(--red)', border:'1px solid color-mix(in srgb, var(--red) 30%, transparent)', borderRadius:10, padding:'10px', fontSize:13, fontWeight:600, cursor:'pointer' }}
                onClick={() => { stopRef.current = true }}
              >
                ⏸ Pause Generation
              </button>
            )}
          </div>
        </div>

        {/* Main content */}
        <div style={{ flex:1, overflowY:'auto', background:'var(--bg)' }}>

          {/* Generation progress bar */}
          {generating && (
            <div style={{ position:'sticky', top:0, zIndex:5, background:'var(--surface)', borderBottom:'1px solid var(--border)', padding:'12px 32px' }}>
              <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:8 }}>
                <div className="spinner" style={{ width:16, height:16 }} />
                <span style={{ fontWeight:600, fontSize:13, color:'var(--accent)' }}>{genStatus}</span>
              </div>
              <div className="progress-bar" style={{ height:6 }}>
                <div className="progress-fill" style={{ width:`${genProgress}%` }} />
              </div>
            </div>
          )}

          <div style={{ maxWidth:800, margin:'0 auto', padding:'40px 40px' }}>

            {/* Outline view */}
            {!selectedChapter && project.outline && (
              <div className="fade-in">
                <h1 className="playfair" style={{ fontSize:38, fontWeight:900, marginBottom:10, lineHeight:1.15 }}>
                  {project.outline.title}
                </h1>
                <p style={{ fontSize:12, color:'var(--accent)', fontWeight:600, letterSpacing:1, marginBottom:6 }}>
                  {genre?.label?.toUpperCase()}
                </p>
                <p className="crimson" style={{ fontSize:19, color:'var(--muted)', marginBottom:36, fontStyle:'italic', lineHeight:1.6 }}>
                  {project.outline.logline}
                </p>

                <h3 style={{ fontWeight:700, fontSize:14, color:'var(--muted)', letterSpacing:1, marginBottom:16 }}>MAIN CHARACTERS</h3>
                <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(240px,1fr))', gap:14, marginBottom:36 }}>
                  {project.outline.mainCharacters?.map(c => (
                    <div key={c.name} className="card" style={{ borderLeft:'3px solid var(--accent)', padding:16 }}>
                      <div style={{ fontWeight:700, marginBottom:3 }}>{c.name}</div>
                      <div style={{ fontSize:12, color:'var(--accent)', fontWeight:600, marginBottom:8 }}>{c.role}</div>
                      <div style={{ fontSize:13, color:'var(--muted)', lineHeight:1.6 }}>{c.description}</div>
                    </div>
                  ))}
                </div>

                <div className="card">
                  <div style={{ fontWeight:700, marginBottom:10, fontSize:14 }}>STORY BACKGROUND</div>
                  <p style={{ fontSize:15, color:'var(--muted)', lineHeight:1.75 }}>{project.outline.background}</p>
                </div>

                {!generating && chaptersDone === 0 && (
                  <div style={{ textAlign:'center', marginTop:40 }}>
                    <button className="btn-gold" style={{ fontSize:17, padding:'16px 48px' }} onClick={generateAll}>
                      ✦ Start Writing Chapters →
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Empty state */}
            {!selectedChapter && !project.outline && (
              <div style={{ textAlign:'center', paddingTop:80 }}>
                <div style={{ fontSize:64, marginBottom:24 }}>✍️</div>
                <h2 className="playfair" style={{ fontSize:30, fontWeight:700, marginBottom:12 }}>Ready to Write</h2>
                <p style={{ color:'var(--muted)', fontSize:15, maxWidth:400, margin:'0 auto 32px', lineHeight:1.65 }}>
                  Click Generate Novel and AI will craft your complete story outline and write all {project.maxChapters} chapters.
                </p>
                <button className="btn-gold" style={{ fontSize:17, padding:'16px 48px' }} onClick={generateAll}>
                  ✦ Generate Novel
                </button>
              </div>
            )}

            {/* Chapter view */}
            {selectedChapter && (
              <div className="fade-in">
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:28, gap:12, flexWrap:'wrap' }}>
                  <div>
                    <div style={{ fontSize:12, color:'var(--accent)', fontWeight:600, letterSpacing:1, marginBottom:6 }}>
                      CHAPTER {selectedChapter.number}
                    </div>
                    <h2 className="playfair" style={{ fontSize:30, fontWeight:700, lineHeight:1.2 }}>
                      {selectedChapter.title}
                    </h2>
                    <div style={{ fontSize:13, color:'var(--muted)', marginTop:6 }}>
                      {(selectedChapter.wordCount || wordCount(selectedChapter.text)).toLocaleString()} words
                    </div>
                  </div>
                  <div style={{ display:'flex', gap:8 }}>
                    {editText !== null ? (
                      <>
                        <button className="btn-ghost" style={{ padding:'9px 16px', fontSize:13 }} onClick={() => setEditText(null)}>Cancel</button>
                        <button className="btn-gold" style={{ padding:'9px 18px', fontSize:13 }} onClick={saveEdit} disabled={saving}>
                          {saving ? '…' : '💾 Save'}
                        </button>
                      </>
                    ) : (
                      <button className="btn-ghost" style={{ padding:'9px 16px', fontSize:13 }} onClick={() => setEditText(selectedChapter.text)}>
                        ✏️ Edit
                      </button>
                    )}
                  </div>
                </div>

                {editText !== null ? (
                  <textarea
                    value={editText}
                    onChange={e => setEditText(e.target.value)}
                    style={{
                      width:'100%', minHeight:700, lineHeight:1.9, fontSize:17,
                      fontFamily:"'Crimson Text', serif", padding:'28px', resize:'vertical',
                      borderRadius:14, border:'2px solid var(--accent)', background:'var(--surface)',
                    }}
                  />
                ) : (
                  <div className="crimson" style={{
                    fontSize:18, lineHeight:1.9, whiteSpace:'pre-wrap',
                    color: theme === 'dark' ? '#D8D0F0' : '#2A1F3A',
                  }}>
                    {selectedChapter.text}
                  </div>
                )}

                {/* Chapter nav */}
                <div style={{ display:'flex', justifyContent:'space-between', marginTop:48, paddingTop:24, borderTop:'1px solid var(--border)' }}>
                  {selectedChapter.number > 1 && (
                    <button className="btn-ghost" style={{ fontSize:14, padding:'11px 22px' }}
                      onClick={() => { setSelectedChapter(project.chapters.find(c => c.number === selectedChapter.number - 1)); setEditText(null) }}>
                      ← Chapter {selectedChapter.number - 1}
                    </button>
                  )}
                  <div style={{ marginLeft:'auto' }}>
                    {selectedChapter.number < chaptersDone && (
                      <button className="btn-ghost" style={{ fontSize:14, padding:'11px 22px' }}
                        onClick={() => { setSelectedChapter(project.chapters.find(c => c.number === selectedChapter.number + 1)); setEditText(null) }}>
                        Chapter {selectedChapter.number + 1} →
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
