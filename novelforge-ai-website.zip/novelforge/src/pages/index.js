// src/pages/index.js
import Link from 'next/link'
import TopBar from '../components/TopBar'
import { GENRES, PACKAGES } from '../lib/pricing'

export default function Landing() {
  return (
    <div>
      <TopBar />

      {/* Hero */}
      <section style={{ textAlign:'center', padding:'110px 24px 80px', maxWidth:900, margin:'0 auto' }}>
        <div style={{
          display:'inline-block',
          background:'color-mix(in srgb, var(--accent) 12%, transparent)',
          border:'1px solid color-mix(in srgb, var(--accent) 35%, transparent)',
          borderRadius:30, padding:'6px 20px', fontSize:13,
          color:'var(--accent)', marginBottom:28, fontWeight:600, letterSpacing:1,
        }}>✦ AI-POWERED WEBNOVEL PLATFORM</div>

        <h1 className="playfair" style={{ fontSize:'clamp(40px,6vw,72px)', lineHeight:1.08, marginBottom:24, fontWeight:900 }}>
          Forge Bestselling<br />
          <span style={{ color:'var(--accent)', fontStyle:'italic' }}>Webnovels</span> with AI
        </h1>

        <p className="crimson" style={{
          fontSize:22, color:'var(--muted)', maxWidth:580, margin:'0 auto 44px', lineHeight:1.65,
        }}>
          Generate complete GoodNovel-quality romance webnovels chapter by chapter.
          2000-word chapters, crushing cliffhangers, rich emotional arcs — all powered by AI.
        </p>

        <div style={{ display:'flex', gap:14, justifyContent:'center', flexWrap:'wrap' }}>
          <Link href="/auth?mode=register">
            <button className="btn-gold" style={{ fontSize:17, padding:'16px 44px' }}>Start Writing Free →</button>
          </Link>
          <a href="#pricing">
            <button className="btn-ghost" style={{ fontSize:16, padding:'15px 32px' }}>See Pricing</button>
          </a>
        </div>

        {/* Stats bar */}
        <div style={{
          display:'flex', justifyContent:'center', gap:40, marginTop:64, flexWrap:'wrap',
        }}>
          {[['7','Genres'],['2,000','Words/Chapter'],['70','Chapters Max'],['100%','AI Generated']].map(([n,l]) => (
            <div key={l} style={{ textAlign:'center' }}>
              <div className="playfair" style={{ fontSize:32, fontWeight:900, color:'var(--accent)' }}>{n}</div>
              <div style={{ fontSize:13, color:'var(--muted)', marginTop:2 }}>{l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Genres */}
      <section style={{ maxWidth:920, margin:'0 auto 100px', padding:'0 24px' }}>
        <h2 className="playfair" style={{ textAlign:'center', fontSize:36, fontWeight:700, marginBottom:14 }}>
          7 Bestselling Genres
        </h2>
        <p style={{ textAlign:'center', color:'var(--muted)', marginBottom:44, fontSize:15 }}>
          Trained on GoodNovel, Dreame & MegaNovel conventions
        </p>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(210px,1fr))', gap:16 }}>
          {GENRES.map(g => (
            <div key={g.id} style={{
              background:'var(--surface)', borderRadius:16,
              border:`1px solid color-mix(in srgb, ${g.color} 35%, var(--border))`,
              padding:'24px 20px', textAlign:'center', cursor:'pointer',
              transition:'transform 0.2s, box-shadow 0.2s',
            }}
              onMouseEnter={e => { e.currentTarget.style.transform='translateY(-5px)'; e.currentTarget.style.boxShadow=`0 16px 40px color-mix(in srgb, ${g.color} 20%, transparent)` }}
              onMouseLeave={e => { e.currentTarget.style.transform=''; e.currentTarget.style.boxShadow='' }}
            >
              <div style={{ fontSize:40, marginBottom:14 }}>{g.emoji}</div>
              <div style={{ fontWeight:700, fontSize:14, color:g.color }}>{g.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section style={{ maxWidth:860, margin:'0 auto 100px', padding:'0 24px' }}>
        <h2 className="playfair" style={{ textAlign:'center', fontSize:36, fontWeight:700, marginBottom:56 }}>
          How It Works
        </h2>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(240px,1fr))', gap:24 }}>
          {[
            ['1','Choose Your Genre','Pick from 7 romance genres. Add a title and idea, or let AI create everything from scratch.'],
            ['2','Select a Package','Choose how many chapters you need: 30 to 70. Pay securely via Paystack or Flutterwave.'],
            ['3','AI Builds Your Novel','AI generates your outline, characters, and 2000-word chapters with cliffhangers automatically.'],
            ['4','Download & Publish','Edit chapters, then download as PDF or DOCX ready to upload to GoodNovel or Dreame.'],
          ].map(([n,t,d]) => (
            <div key={n} className="card" style={{ position:'relative' }}>
              <div style={{
                width:40, height:40, borderRadius:'50%',
                background:'linear-gradient(135deg, var(--accent), #A8832A)',
                display:'flex', alignItems:'center', justifyContent:'center',
                fontSize:18, fontWeight:900, color:'#0D0B12', marginBottom:16,
              }}>{n}</div>
              <div style={{ fontWeight:700, fontSize:16, marginBottom:8 }}>{t}</div>
              <div style={{ fontSize:13, color:'var(--muted)', lineHeight:1.65 }}>{d}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" style={{ maxWidth:840, margin:'0 auto 100px', padding:'0 24px' }}>
        <h2 className="playfair" style={{ textAlign:'center', fontSize:36, fontWeight:700, marginBottom:14 }}>
          Simple, Transparent Pricing
        </h2>
        <p style={{ textAlign:'center', color:'var(--muted)', marginBottom:50, fontSize:15 }}>
          Pay once. Generate your complete novel. No subscriptions.
        </p>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(148px,1fr))', gap:14 }}>
          {PACKAGES.map((pkg, i) => (
            <div key={pkg.chapters} className="card" style={{
              textAlign:'center', padding:24,
              border:`2px solid ${i===2 ? 'var(--accent)' : 'var(--border)'}`,
              position:'relative',
              background: i===2 ? 'color-mix(in srgb, var(--accent) 6%, var(--surface))' : 'var(--surface)',
            }}>
              {i===2 && (
                <div style={{
                  position:'absolute', top:-14, left:'50%', transform:'translateX(-50%)',
                  background:'linear-gradient(135deg, var(--accent), #A8832A)',
                  color:'#0D0B12', fontSize:11, fontWeight:700, padding:'4px 14px', borderRadius:20,
                  whiteSpace:'nowrap',
                }}>MOST POPULAR</div>
              )}
              <div className="playfair" style={{ fontSize:34, fontWeight:900, color:'var(--accent)' }}>{pkg.chapters}</div>
              <div style={{ fontSize:11, color:'var(--muted)', marginBottom:10 }}>chapters</div>
              <div style={{ fontWeight:700, fontSize:17 }}>₦{pkg.price.toLocaleString()}</div>
              <div style={{ fontSize:11, color:'var(--muted)', marginTop:4 }}>{pkg.label}</div>
            </div>
          ))}
        </div>
        <div style={{ textAlign:'center', marginTop:24 }}>
          <Link href="/auth?mode=register">
            <button className="btn-gold" style={{ fontSize:16, padding:'14px 40px' }}>
              Start Your Novel →
            </button>
          </Link>
        </div>
      </section>

      {/* Features */}
      <section style={{ maxWidth:900, margin:'0 auto 100px', padding:'0 24px' }}>
        <h2 className="playfair" style={{ textAlign:'center', fontSize:36, fontWeight:700, marginBottom:50 }}>
          Everything You Need to Publish
        </h2>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(260px,1fr))', gap:20 }}>
          {[
            ['📖','2000-Word Chapters','Every chapter is a complete, richly written scene. Perfect for platform requirements.'],
            ['⚡','Auto-Cliffhangers','Every chapter ends with a hook that compels readers to click next.'],
            ['🎭','Consistent Characters','AI remembers your characters across all chapters for coherent storytelling.'],
            ['📥','PDF & DOCX Export','Download your finished novel, ready to submit to GoodNovel, Dreame, or MegaNovel.'],
            ['💾','Auto-Save','Your work saves automatically after every chapter generated.'],
            ['✏️','Chapter Editor','Edit any chapter directly in the browser before downloading.'],
            ['🔒','Secure Payments','Paystack & Flutterwave — Nigeria\'s most trusted payment gateways.'],
            ['📊','Progress Tracking','Visual progress bar shows exactly how many chapters are complete.'],
            ['🌙','Dark & Light Mode','Write comfortably any time of day with full theme support.'],
          ].map(([icon,t,d]) => (
            <div key={t} className="card" style={{ display:'flex', flexDirection:'column', gap:10 }}>
              <div style={{ fontSize:30 }}>{icon}</div>
              <div style={{ fontWeight:700, fontSize:15 }}>{t}</div>
              <div style={{ fontSize:13, color:'var(--muted)', lineHeight:1.65 }}>{d}</div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section style={{
        maxWidth:700, margin:'0 auto 80px', padding:'60px 24px',
        textAlign:'center',
        background:'var(--surface)', borderRadius:24,
        border:'1px solid var(--border)',
      }}>
        <div style={{ fontSize:48, marginBottom:16 }}>✍️</div>
        <h2 className="playfair" style={{ fontSize:36, fontWeight:700, marginBottom:14 }}>
          Ready to Write Your Novel?
        </h2>
        <p style={{ color:'var(--muted)', marginBottom:36, fontSize:16, lineHeight:1.6 }}>
          Join hundreds of authors using NovelForge AI to publish on GoodNovel, Dreame & MegaNovel.
        </p>
        <Link href="/auth?mode=register">
          <button className="btn-gold" style={{ fontSize:17, padding:'16px 48px' }}>
            Create Free Account →
          </button>
        </Link>
      </section>

      {/* Footer */}
      <footer style={{
        borderTop:'1px solid var(--border)', padding:'32px 24px',
        textAlign:'center', color:'var(--muted)', fontSize:13,
      }}>
        <p>© 2024 NovelForge AI · Built for webnovel authors · Nigeria's #1 AI Novel Generator</p>
        <p style={{ marginTop:8 }}>Payments secured by Paystack & Flutterwave</p>
      </footer>
    </div>
  )
}
