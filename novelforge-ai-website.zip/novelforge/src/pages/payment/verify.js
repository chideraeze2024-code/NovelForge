// src/pages/payment/verify.js
import { useEffect, useState } from 'react'
import { useRouter } from 'next/router'
import TopBar from '../../components/TopBar'
import { useAuth } from '../_app'

export default function VerifyPayment() {
  const router = useRouter()
  const { apiFetch } = useAuth()
  const [status, setStatus] = useState('verifying') // verifying | success | failed

  useEffect(() => {
    const ref = router.query.ref || router.query.reference || router.query.trxref
    if (!ref) { setStatus('failed'); return }
    verify(ref)
  }, [router.query])

  const verify = async (ref) => {
    try {
      const res = await fetch(`/api/payments/verify?ref=${ref}`)
      const data = await res.json()
      if (data.success) {
        setStatus('success')
        setTimeout(() => router.push(`/editor/${data.projectId}`), 2000)
      } else {
        setStatus('failed')
      }
    } catch {
      setStatus('failed')
    }
  }

  return (
    <div>
      <TopBar />
      <div style={{ minHeight:'calc(100vh - 64px)', display:'flex', alignItems:'center', justifyContent:'center', padding:24 }}>
        <div className="card fade-in" style={{ maxWidth:440, width:'100%', textAlign:'center', padding:48 }}>
          {status === 'verifying' && (
            <>
              <div className="spinner" style={{ width:48, height:48, margin:'0 auto 24px' }} />
              <h2 className="playfair" style={{ fontSize:26, fontWeight:700, marginBottom:10 }}>Verifying Payment</h2>
              <p style={{ color:'var(--muted)' }}>Please wait while we confirm your payment…</p>
            </>
          )}
          {status === 'success' && (
            <>
              <div style={{ fontSize:64, marginBottom:20 }}>🎉</div>
              <h2 className="playfair" style={{ fontSize:30, fontWeight:700, color:'var(--accent)', marginBottom:12 }}>
                Payment Confirmed!
              </h2>
              <p style={{ color:'var(--muted)', marginBottom:24 }}>Your chapters are unlocked. Redirecting to your editor…</p>
              <div className="spinner" style={{ margin:'0 auto' }} />
            </>
          )}
          {status === 'failed' && (
            <>
              <div style={{ fontSize:64, marginBottom:20 }}>❌</div>
              <h2 className="playfair" style={{ fontSize:26, fontWeight:700, marginBottom:12 }}>Payment Failed</h2>
              <p style={{ color:'var(--muted)', marginBottom:24 }}>Your payment could not be verified. Please try again or contact support.</p>
              <button className="btn-gold" onClick={() => router.push('/dashboard')}>Back to Dashboard</button>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
